const translations = {
  fever: {
    en: { title: "Fever: general guidance", body: "Rest, drink fluids, and monitor how you feel. Use medicines only as directed by a qualified healthcare professional or the product label. Seek medical advice for persistent or worsening fever, and for infants or people with significant health conditions.", urgent: "Get urgent help for difficulty breathing, confusion, seizures, severe dehydration, stiff neck, or a very unwell child." },
    hi: { title: "बुखार: सामान्य जानकारी", body: "आराम करें, पर्याप्त तरल लें और अपनी स्थिति पर ध्यान दें। दवा केवल स्वास्थ्यकर्मी की सलाह या लेबल के अनुसार लें। बुखार लगातार रहे या बढ़े, अथवा शिशु/गंभीर बीमारी वाले व्यक्ति को बुखार हो, तो चिकित्सा सलाह लें।", urgent: "साँस लेने में कठिनाई, भ्रम, दौरा, पानी की गंभीर कमी, गर्दन अकड़ना या बच्चा बहुत बीमार दिखे तो तुरंत मदद लें।" }
  },
  cough: {
    en: { title: "Cough / cold: general guidance", body: "Rest and drink fluids. Avoid smoking and exposure to smoke. Do not give antibiotics or cough medicines to children without professional advice. Ask a healthcare professional if symptoms worsen or persist.", urgent: "Seek urgent care for difficulty breathing, blue/grey lips, chest pain, or severe weakness." },
    hi: { title: "खाँसी / जुकाम: सामान्य जानकारी", body: "आराम करें और पर्याप्त तरल लें। धूम्रपान और धुएँ से बचें। बच्चों को बिना स्वास्थ्यकर्मी की सलाह के एंटीबायोटिक या खाँसी की दवा न दें। लक्षण बढ़ें या बने रहें तो सलाह लें।", urgent: "साँस लेने में कठिनाई, होंठ नीले/धूसर होना, सीने में दर्द या बहुत कमजोरी होने पर तुरंत मदद लें।" }
  },
  diarrhea: {
    en: { title: "Diarrhoea: hydration matters", body: "Prevent dehydration by taking safe fluids. Oral rehydration solution (ORS) can help when prepared exactly as instructed on the packet using safe water. Continue age-appropriate food and seek professional advice, especially for young children.", urgent: "Get urgent care for blood in stool, inability to drink, very little urine, unusual sleepiness, or signs of severe dehydration." },
    hi: { title: "दस्त: पानी की कमी से बचें", body: "सुरक्षित तरल लेते रहें। ORS को पैकेट पर दिए निर्देशों के अनुसार सुरक्षित पानी में ही बनाएँ। उम्र के अनुसार भोजन जारी रखें और विशेषकर छोटे बच्चों के लिए स्वास्थ्यकर्मी से सलाह लें।", urgent: "मल में खून, पानी न पी पाना, बहुत कम पेशाब, असामान्य सुस्ती या पानी की गंभीर कमी के संकेत हों तो तुरंत चिकित्सा सहायता लें।" }
  },
  emergency: {
    en: { title: "Emergency warning signs", body: "Call your local emergency service or go to the nearest emergency department for severe or rapidly worsening symptoms. In India, 112 is the pan-India emergency number; availability and response can vary by location.", urgent: "Warning signs include severe breathing difficulty, suspected stroke (face drooping, arm weakness, speech trouble), unconsciousness, major bleeding, or severe chest pain." },
    hi: { title: "आपातकालीन चेतावनी संकेत", body: "गंभीर या तेजी से बिगड़ते लक्षणों में स्थानीय आपातकालीन सेवा से संपर्क करें या नज़दीकी इमरजेंसी विभाग जाएँ। भारत में 112 अखिल भारतीय आपातकालीन नंबर है; स्थानीय उपलब्धता अलग हो सकती है।", urgent: "गंभीर साँस की परेशानी, स्ट्रोक के संकेत (चेहरा टेढ़ा, हाथ में कमजोरी, बोलने में कठिनाई), बेहोशी, अधिक खून बहना या तेज सीने का दर्द चेतावनी संकेत हैं।" }
  }
};
const facilities = [
  {name:"Sample Primary Health Centre", area:"Demo Village A", type:"PRIMARY HEALTH CENTRE", services:["General consultation","Maternal & child health","Basic medicines"], note:"Demonstration record — replace with verified local details."},
  {name:"Sample Community Health Centre", area:"Demo Block B", type:"COMMUNITY HEALTH CENTRE", services:["Outpatient services","Referral support","Basic diagnostics"], note:"Demonstration record — call/verify before travelling."},
  {name:"Sample District Hospital", area:"Demo District HQ", type:"DISTRICT HOSPITAL", services:["Emergency department","Specialist services","Laboratory"], note:"Demonstration record — not a verified real listing."}
];
let lang = "en";
const $ = (selector) => document.querySelector(selector);
function renderGuidance(topic) {
  const item = translations[topic][lang];
  $("#guidancePanel").innerHTML = `<h3>${item.title}</h3><p>${item.body}</p><p><strong>${lang==="en"?"Warning signs:":"चेतावनी संकेत:"}</strong> ${item.urgent}</p>`;
}
document.querySelectorAll(".topic").forEach(btn => btn.addEventListener("click", () => renderGuidance(btn.dataset.topic)));
function renderFacilities() {
  const q = $("#facilitySearch").value.trim().toLowerCase();
  const filtered = facilities.filter(f => [f.name,f.area,f.type,...f.services].join(" ").toLowerCase().includes(q));
  $("#facilityCount").textContent = `${filtered.length} ${lang==="en"?"results":"परिणाम"}`;
  $("#facilityList").innerHTML = filtered.map(f => `<article class="facility"><span class="type">${f.type}</span><h3>${f.name}</h3><p>📍 ${f.area}</p><p class="services">${f.services.join(" • ")}</p><p><em>${f.note}</em></p></article>`).join("") || `<p class="empty">${lang==="en"?"No sample facilities match your search.":"आपकी खोज से मेल खाता कोई नमूना केंद्र नहीं मिला।"}</p>`;
}
$("#facilitySearch").addEventListener("input", renderFacilities);
function getReminders() { try { return JSON.parse(localStorage.getItem("sehatReminders") || "[]"); } catch { return []; } }
function saveReminders(items) { localStorage.setItem("sehatReminders", JSON.stringify(items)); }
function renderReminders() {
  const items = getReminders().sort((a,b)=>a.time.localeCompare(b.time));
  $("#reminderList").innerHTML = items.length ? items.map((r,i)=>`<div class="reminder-item"><div><strong>${escapeHTML(r.name)}</strong><small>${r.time}${r.note ? " • "+escapeHTML(r.note):""}</small></div><button class="delete-btn" data-delete="${r.id}" type="button">${lang==="en"?"Delete":"हटाएँ"}</button></div>`).join("") : `<p class="empty">${lang==="en"?"No reminders yet.":"अभी कोई रिमाइंडर नहीं है।"}</p>`;
  document.querySelectorAll("[data-delete]").forEach(b=>b.addEventListener("click",()=>{saveReminders(getReminders().filter(r=>r.id!==b.dataset.delete));renderReminders();}));
}
function escapeHTML(s) { return String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
$("#reminderForm").addEventListener("submit", e=>{
  e.preventDefault();
  const name=$("#medicineName").value.trim(), time=$("#medicineTime").value, note=$("#medicineNote").value.trim();
  if(!name || !time) return;
  const items=getReminders(); items.push({id:crypto.randomUUID ? crypto.randomUUID() : String(Date.now()),name,time,note});
  saveReminders(items); e.target.reset(); renderReminders();
});
$("#languageToggle").addEventListener("click",()=>{
  lang=lang==="en"?"hi":"en";
  document.documentElement.lang=lang;
  document.querySelectorAll("[data-en][data-hi]").forEach(el=>el.textContent=el.dataset[lang]);
  $("#languageToggle").textContent=lang==="en"?"हिन्दी":"English";
  $("#facilitySearch").placeholder=lang==="en"?"Search by name, area, or service…":"नाम, क्षेत्र या सेवा से खोजें…";
  renderFacilities();renderReminders();
  const panelTitle=$("#guidancePanel h3");
  if(panelTitle && panelTitle.textContent!=="Select a health topic" && panelTitle.textContent!=="स्वास्थ्य विषय चुनें"){
    const selected=Object.keys(translations).find(k=>translations[k].en.title===panelTitle.textContent || translations[k].hi.title===panelTitle.textContent);
    if(selected)renderGuidance(selected);
  }
});
renderFacilities();renderReminders();
