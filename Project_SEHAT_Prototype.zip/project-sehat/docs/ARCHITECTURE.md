# Project SEHAT — Architecture Notes

## Prototype architecture
This is a static, client-side web application.

```text
User (mobile / desktop browser)
        |
        v
index.html (semantic UI)
        |
        +--> styles.css (responsive visual layer)
        |
        +--> app.js
               |
               +--> predefined health education content
               +--> browser localStorage (medicine reminders)
               +--> local sample facility records
```

## Main modules
- **Language layer:** switches text between English and Hindi using `data-en` and `data-hi` attributes.
- **Health guide:** displays predefined general information and warning signs. It is not a diagnosis engine.
- **Medicine reminders:** validates name and time, stores reminders in `localStorage`, and supports deletion.
- **Facility search:** filters sample facility records by name, area, type, and services.

## Data flow and privacy
- No data is transmitted to a server.
- Reminder entries stay in the browser's local storage on that device.
- There is no login, analytics, tracking, or third-party API integration.
- Users should avoid entering sensitive information on shared devices and clear browser data when appropriate.

## Production architecture (future work, not implemented)
1. Replace sample directory with an authoritative, maintained facility dataset or approved API.
2. Add optional geolocation only after explicit consent; provide manual location search as an alternative.
3. Add offline caching/service worker and test on low-cost Android devices and weak networks.
4. Add optional speech-to-text/text-to-speech with clear consent and a manual fallback.
5. If adding a backend, use secure authentication, encryption, access controls, retention limits, audit logs, and a privacy impact assessment.
6. Clinical content should be reviewed by qualified health professionals and localized with community feedback.

## Safety boundaries
- No diagnosis, prescriptions, drug dose recommendations, or claims of verified facility availability.
- Emergency guidance directs users to local emergency services / professional care; the prototype cannot dispatch help.
- All sample facilities are fictional and clearly labelled.
