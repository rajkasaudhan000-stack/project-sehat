# Project SEHAT — Smart Healthcare Assistant for Rural India

A lightweight, bilingual (English/Hindi) front-end prototype for improving access to general health education, medicine reminders, and public health facility information in rural communities.

> **Safety notice:** This is an educational hackathon prototype, not a medical device and not a substitute for a qualified healthcare professional. It does not diagnose conditions, prescribe treatment, or contact emergency services. Facility listings are clearly marked sample data and must be replaced with verified local information before real-world use.

## Features
- English/Hindi interface toggle.
- General health education cards for fever, cough/cold, diarrhoea, and emergency warning signs.
- Medicine reminder form; reminders are stored in browser `localStorage`.
- Searchable sample public-health facility directory.
- Responsive layout for mobile and desktop.
- Lightweight static site; no backend or account required.

## Run locally
1. Download or clone this repository.
2. Open `index.html` in a modern browser.
3. To test with a local web server (recommended):
   ```bash
   python -m http.server 8000
   ```
4. Visit `http://localhost:8000`.

No API keys, build tools, or paid services are required. The Google Fonts import is optional; the site falls back to system fonts if offline.

## Repository structure
```text
project-sehat/
├── index.html
├── styles.css
├── app.js
├── data/
│   └── sample-facilities.json
├── docs/
│   └── ARCHITECTURE.md
├── tests/
│   └── TEST_CASES.md
├── LICENSE
└── README.md
```

## Architecture
See [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md).

## Sample data
`data/sample-facilities.json` contains fictional records used for demonstration. Do not present them as real facilities. Replace them only with verified information from authoritative public sources and include last-verified dates.

## Tests
Manual test cases are listed in [`tests/TEST_CASES.md`](tests/TEST_CASES.md).

## Current limitations / next steps
- The prototype uses predefined educational content; it does not use a live AI model.
- Medicine reminders are browser-local and do not trigger background notifications.
- Facility data is fictional sample data; there is no live map, GPS, or live availability.
- Voice input/output, offline caching, backend sync, verified directory integration, privacy review, accessibility testing, and clinical review are future improvements.
- Do not add personal medical records or real patient information to the demo.

## Suggested hackathon demo
1. Switch the interface to Hindi.
2. Open the fever or emergency warning card.
3. Add a medicine reminder and show it in the list.
4. Search the sample facility directory.
5. Explain how verified facility data and offline-first features would be added after field validation.

## UN SDG alignment
- **SDG 3:** Good Health and Well-being.
- **SDG 10:** Reduced Inequalities.
- **SDG 9:** Industry, Innovation and Infrastructure.

## License
MIT. See [`LICENSE`](LICENSE).
