# Manual Test Cases

Run the site in a modern browser and check the following.

| ID | Test | Steps | Expected result |
|---|---|---|---|
| T01 | Initial page load | Open `index.html` | Header, hero, health topics, reminder form, and sample facilities appear without errors. |
| T02 | Language toggle | Click हिन्दी / English | Main interface labels switch between English and Hindi. |
| T03 | Health guide | Click Fever | General fever guidance and warning signs appear. |
| T04 | Emergency guidance | Click Emergency signs | Urgent warning signs and seek-care guidance appear. |
| T05 | Add reminder | Enter medicine name and time; submit | Reminder appears in Upcoming reminders. |
| T06 | Required validation | Submit empty reminder form | Browser blocks submission because required fields are missing. |
| T07 | Persist reminder | Add reminder and refresh page | Reminder remains in the same browser. |
| T08 | Delete reminder | Click Delete / हटाएँ | Selected reminder disappears and stays deleted after refresh. |
| T09 | Search facilities | Search for “hospital” | Matching sample district hospital is shown. |
| T10 | Empty facility search | Search for an unmatched phrase | Empty-results message appears. |
| T11 | Responsive layout | Test at narrow mobile width | Cards and sections stack without horizontal overflow. |
| T12 | Safety disclosure | Review the warning banner and facility cards | Medical limitations and fictional sample-data caveat are visible. |

## Automated checks
This version has no automated test runner. The table above is a manual smoke-test checklist. A future version can add Playwright tests and accessibility checks.
